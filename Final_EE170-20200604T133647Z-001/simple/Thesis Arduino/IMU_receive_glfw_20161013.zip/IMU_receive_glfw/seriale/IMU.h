#include <tchar.h>
#include <string>
#include <conio.h>
#include <time.h>
#include <math.h>

// Constant values which should not be touched
#define PACKET_SIZE 16 // size of packet received from Arduino via Serial
#define RAD_TO_DEG (double)57.295777951 // convert radiants to degree
#define INTEGRATION_TIME (double)0.05 // integration time is 0.1s (each sample is received at this interval time)
#define GYRO_TO_RAD (double)0.000132961 // converts gyro raw data to rad per second (3.14/180)*(1/131.2). Gyro range is 131.2 LSB/(deg/s)

// Constant values for tuning filtering algorithm
#define G_OFFSET_CORR_ACT_FLAG 1
#define Q_OFFSET_CORR_ACT_FLAG 0
#define A_HIST_NUM (unsigned long)10 // number of samples for acceleration sensor history
#define G_HIST_NUM (unsigned long)20 // number of samples for gyroscope sensor history
#define A_STEADY_STATE_AVERAGE_THR (unsigned long)160
#define A_STEADY_STATE_SIGMA_THR (unsigned long)160
#define G_STEADY_STATE_THR (long)50
#define FILTER_REQ_FILT_CONST (double)0.2 // constant for filtering priority filter value
#define FILTER_REQ_MIN (double) 0.1 // gyroscope quaternion has high priority
#define FILTER_REQ_MAX (double) 0.5 // acceleration quaternion has high priority

// Fast inverse square root algorithm
float invSqrt(float x) {
	float halfx = 0.5f * x;
	float y = x;
	long i = *(long*)&y;
	i = 0x5f3759df - (i >> 1);
	y = *(float*)&i;
	y = y * (1.5f - (halfx * y * y));
	return y;
}

// IMU Class
class IMU_class{
public:
	IMU_class(); // constructor, to initialize data
	void parse_incoming_packet(); // retrieves raw data inside packet
	void correct_raw_data(); // fixes the sign and scale, and arranges data into float format
	void calculation_task();
	void calculation_task_2();
	void calculate_rotation_matrix_elements_a(double yaw); // the yaw angle must be given as input
	void calculate_quaternion_elements_a();
	void calculate_yawpitchroll_from_quaternions(double* q_in, double* yaw_out, double* pitch_out, double* roll_out);
	void integrate_quaternion_g(double* q_in, double* q_out);
	void fuse_quaternions(double* q_in1, double* q_in2, double* q_out, double kf);
	void normalize_quaternion(double* q_in);
	void update_filter_constant_using_acc_history();
	char* packet_data;
	short ax, ay, az; // raw data (acceleration)
	short gx, gy, gz; // raw data (gyroscope)
	unsigned short a_modulus; // acceleration raw data modulus
	unsigned short packet_counter; // counter for received packets
	double yaw_a, pitch_a, roll_a; // yaw, pitch, roll calculated from acceleration data
	double yaw_fuse, pitch_fuse, roll_fuse; // yaw, pitch, roll calculated from fusion between acceleration data and gyroscope data
	
	int yaw_bypass_request;

	double ax_f, ay_f, az_f; // acceleration raw data (floating point)
	double gx_f, gy_f, gz_f; // gyroscope raw data (floating point)
	double sin_psi_a; // yaw (calculated based on acceleration sensor)
	double cos_psi_a;
	double sin_teta_a; // pitch (calculated based on acceleration sensor)
	double cos_teta_a;
	double sin_phi_a; // roll (calculated based on acceleration sensor)
	double cos_phi_a;
	double R_a[3][3]; // rotation matrix calculated from acceleration data
	double q_a[4]; // quaternion (acceleration)
	double q_g[4]; // quaternion (gyroscope)
	double q_fuse[4]; // quaternion (fused)
	double q_diff[4]; // difference between quaternion and previous
	double q_diff_offset[4]; // offset estimated for quaternion
	
	// History variables
	unsigned int a_samples_index;
	unsigned long a_samples_hist[A_HIST_NUM];
	unsigned int g_samples_index;
	long gx_samples_hist[G_HIST_NUM];
	long gy_samples_hist[G_HIST_NUM];
	long gz_samples_hist[G_HIST_NUM];
	double q_diff_hist[G_HIST_NUM][4];
	short gx_offset;
	short gy_offset;
	short gz_offset;
	double filter_requested;
};

void IMU_class::update_filter_constant_using_acc_history(){

	unsigned int i = 0; // counter

	// Saves current acceleration sample in the history array
	if (a_samples_index >= A_HIST_NUM) a_samples_index = 0;
	a_samples_hist[a_samples_index] = (unsigned long)a_modulus;

	// Calculates acceleration array average and sigma
	unsigned long average_acc_hist = 0;
	unsigned long sigma_acc_hist = 0;
	for (i = 0; i < A_HIST_NUM; i++){
		average_acc_hist += a_samples_hist[i];
	}
	average_acc_hist = average_acc_hist/A_HIST_NUM;
	for (i = 0; i < A_HIST_NUM; i++){
		sigma_acc_hist += (a_samples_hist[i] - average_acc_hist)*(a_samples_hist[i] - average_acc_hist);
	}
	sigma_acc_hist = sigma_acc_hist / A_HIST_NUM;
	sigma_acc_hist = (unsigned long)sqrt((float)sigma_acc_hist);

	// Calculates gyroscope arrays average and sigma
	long average_gx_hist = 0;
	long average_gy_hist = 0;
	long average_gz_hist = 0;
	long sigma_gx_hist = 0;
	long sigma_gy_hist = 0;
	long sigma_gz_hist = 0;
	double ave_q_diff_hist[4];
	ave_q_diff_hist[0] = 0;
	ave_q_diff_hist[1] = 0;
	ave_q_diff_hist[2] = 0;
	ave_q_diff_hist[3] = 0;
	for (i = 0; i < G_HIST_NUM; i++){
		average_gx_hist += gx_samples_hist[i];
		average_gy_hist += gy_samples_hist[i];
		average_gz_hist += gz_samples_hist[i];
		ave_q_diff_hist[0] += q_diff_hist[i][0];
		ave_q_diff_hist[1] += q_diff_hist[i][1];
		ave_q_diff_hist[2] += q_diff_hist[i][2];
		ave_q_diff_hist[3] += q_diff_hist[i][3];
	}
	average_gx_hist /= (long)G_HIST_NUM;
	average_gy_hist /= (long)G_HIST_NUM;
	average_gz_hist /= (long)G_HIST_NUM;
	ave_q_diff_hist[0] /= (double)G_HIST_NUM;
	ave_q_diff_hist[1] /= (double)G_HIST_NUM;
	ave_q_diff_hist[2] /= (double)G_HIST_NUM;
	ave_q_diff_hist[3] /= (double)G_HIST_NUM;
	for (i = 0; i < G_HIST_NUM; i++){
		sigma_gx_hist += (gx_samples_hist[i] - average_gx_hist)*(gx_samples_hist[i] - average_gx_hist);
		sigma_gy_hist += (gy_samples_hist[i] - average_gy_hist)*(gy_samples_hist[i] - average_gy_hist);
		sigma_gz_hist += (gz_samples_hist[i] - average_gz_hist)*(gz_samples_hist[i] - average_gz_hist);
	}
	sigma_gx_hist = sigma_gx_hist / G_HIST_NUM;
	sigma_gy_hist = sigma_gy_hist / G_HIST_NUM;
	sigma_gz_hist = sigma_gz_hist / G_HIST_NUM;
	sigma_gx_hist = (unsigned long)sqrt((float)sigma_gx_hist);
	sigma_gy_hist = (unsigned long)sqrt((float)sigma_gy_hist);
	sigma_gz_hist = (unsigned long)sqrt((float)sigma_gz_hist);

	// Determines the filtering contant, based on the acceleration
	double filter_requested_now;
	if ((a_samples_hist[a_samples_index] < (average_acc_hist - A_STEADY_STATE_AVERAGE_THR)) || (a_samples_hist[a_samples_index] > (average_acc_hist + A_STEADY_STATE_AVERAGE_THR))){
		filter_requested_now = FILTER_REQ_MIN;
	}
	else{
		filter_requested_now = FILTER_REQ_MAX;
	}
	
	// Evaluate if the sensor is moving or not //
	if ((!yaw_bypass_request) && (sigma_acc_hist < A_STEADY_STATE_SIGMA_THR) && (gx>(average_gx_hist - G_STEADY_STATE_THR)) && (gx<(average_gx_hist + G_STEADY_STATE_THR)) && (gy>(average_gy_hist - G_STEADY_STATE_THR)) && (gy<(average_gy_hist + G_STEADY_STATE_THR)) && (gz>(average_gz_hist - G_STEADY_STATE_THR)) && (gz<(average_gz_hist + G_STEADY_STATE_THR))){
		if (g_samples_index >= G_HIST_NUM) g_samples_index = 0; // Saves current sample in the history array
		gx_samples_hist[g_samples_index] = (long)gx;
		gy_samples_hist[g_samples_index] = (long)gy;
		gz_samples_hist[g_samples_index] = (long)gz;
		q_diff_hist[g_samples_index][0] = q_diff[0];
		q_diff_hist[g_samples_index][1] = q_diff[1];
		q_diff_hist[g_samples_index][2] = q_diff[2];
		q_diff_hist[g_samples_index][3] = q_diff[3];
		gx_offset = (short)average_gx_hist;
		gy_offset = (short)average_gy_hist;
		gz_offset = (short)average_gz_hist;
		/*q_diff_offset[0] = ave_q_diff_hist[0];
		q_diff_offset[1] = ave_q_diff_hist[1];
		q_diff_offset[2] = ave_q_diff_hist[2];
		q_diff_offset[3] = ave_q_diff_hist[3];*/
		q_diff_offset[0] = q_diff[0];
		q_diff_offset[1] = q_diff[1];
		q_diff_offset[2] = q_diff[2];
		q_diff_offset[3] = q_diff[3];
	}

	filter_requested = FILTER_REQ_FILT_CONST*filter_requested_now + ((double)1.0 - FILTER_REQ_FILT_CONST)*filter_requested; // filtering of filter constant
	
	printf("Modulo medio= %d. Sigma= %d. Ora= %d. Filter= %f.\n", average_acc_hist, sigma_acc_hist, a_samples_hist[a_samples_index], filter_requested);
	printf("gx_a=%d gy_a=%d gz_a=%d gx_s=%d gy_s=%d gz_s=%d\n", gx_offset, gy_offset, gz_offset, sigma_gx_hist, sigma_gy_hist, sigma_gz_hist);
	//printf("%f %f %f %f\n", ave_q_diff_hist[0], ave_q_diff_hist[1], ave_q_diff_hist[2], ave_q_diff_hist[3]);

	g_samples_index++; // increase array number
	a_samples_index++; // increase array number

}

void IMU_class::normalize_quaternion(double* q_in){
	double recipNorm;
	//recipNorm = (double)invSqrt((float)(q_in[0] * q_in[0] + q_in[1] * q_in[1] + q_in[2] * q_in[2] + q_in[3] * q_in[3])); // normalize quaternion
	recipNorm = 1 / sqrt(q_in[0] * q_in[0] + q_in[1] * q_in[1] + q_in[2] * q_in[2] + q_in[3] * q_in[3]);
	q_in[0] *= recipNorm;
	q_in[1] *= recipNorm;
	q_in[2] *= recipNorm;
	q_in[3] *= recipNorm;
}

void IMU_class::fuse_quaternions(double* q_in1, double* q_in2, double* q_out, double kf){
	// Filter
	q_out[0] = kf*q_in1[0] + (1 - kf)*q_in2[0];
	q_out[1] = kf*q_in1[1] + (1 - kf)*q_in2[1];
	q_out[2] = kf*q_in1[2] + (1 - kf)*q_in2[2];
	q_out[3] = kf*q_in1[3] + (1 - kf)*q_in2[3];
	// Scaling quaternion
	// normalize_quaternion(q_out); // Optional
}

// Receives a quaternion as input and calculates the new quaternion based on gyroscope data
void IMU_class::integrate_quaternion_g(double* q_in, double* q_out){

	// Saves old quaternion values to evaluate integration error
	double q_out_old[4];
	q_out_old[0] = q_out[0];
	q_out_old[1] = q_out[1];
	q_out_old[2] = q_out[2];
	q_out_old[3] = q_out[3];

	// Rate of change of quaternion from gyroscope
	double qDot[4];
	qDot[0] = 0.5f * (-q_in[1] * gx_f - q_in[2] * gy_f - q_in[3] * gz_f);
	qDot[1] = 0.5f * (q_in[0] * gx_f + q_in[2] * gz_f - q_in[3] * gy_f);
	qDot[2] = 0.5f * (q_in[0] * gy_f - q_in[1] * gz_f + q_in[3] * gx_f);
	qDot[3] = 0.5f * (q_in[0] * gz_f + q_in[1] * gy_f - q_in[2] * gx_f);

	// Time integration
	q_out[0] = q_in[0] + qDot[0] * INTEGRATION_TIME;
	q_out[1] = q_in[1] + qDot[1] * INTEGRATION_TIME;
	q_out[2] = q_in[2] + qDot[2] * INTEGRATION_TIME;
	q_out[3] = q_in[3] + qDot[3] * INTEGRATION_TIME;

	// Evaluates difference between previous quaternion and present quaternion
	q_diff[0] = q_out[0] - q_out_old[0];
	q_diff[1] = q_out[1] - q_out_old[1];
	q_diff[2] = q_out[2] - q_out_old[2];
	q_diff[3] = q_out[3] - q_out_old[3];

	// Correct quaternion offset (to avoid continuous incrementation due to calculation error, offsets, and so on...)
	if ((!yaw_bypass_request) && Q_OFFSET_CORR_ACT_FLAG){
		q_out[0] -= q_diff_offset[0];
		q_out[1] -= q_diff_offset[1];
		q_out[2] -= q_diff_offset[2];
		q_out[3] -= q_diff_offset[3];
	}

	// Scaling quaternion
	normalize_quaternion(q_out);

	//printf("%f %f %f %f\n\n", q_out[0], q_out[1], q_out[2], q_out[3]);
}

// Calculates rotation matrix elements values, starting from acceleration sensor data and yaw angle (received as an input)
// Please remember that, by only using acceleration data, it is not possible to calculate the yaw angle
void IMU_class::calculate_rotation_matrix_elements_a(double yaw){
	// Calculates cosinus and sinus of pitch and roll angles, from normalized (-1, +1) range acceleration sensor data
	sin_teta_a = -ax_f;
	cos_teta_a = sqrt(1 - sin_teta_a*sin_teta_a);
	if (cos_teta_a == 0.0){ // Gimbal Lock
		sin_phi_a = 0;
		cos_phi_a = 1;
	}
	else{
		sin_phi_a = ay_f / cos_teta_a;
		//cos_phi_a = sqrt(1 - sin_phi_a*sin_phi_a);
		cos_phi_a = az_f / cos_teta_a;
	}
	// Calculates elements third column elements [Z axis is 1g]
	R_a[0][2] = ax_f;
	R_a[1][2] = ay_f;
	R_a[2][2] = az_f;
	// Calculates other elements starting from yaw angle value (psi), which is received from thrustful source (GPS, ...)
	sin_psi_a = sin(yaw);
	cos_psi_a = cos(yaw);
	R_a[0][0] = cos_teta_a*cos_psi_a;
	R_a[0][1] = cos_teta_a*sin_psi_a;
	R_a[1][0] = -cos_phi_a*sin_psi_a + sin_phi_a*sin_teta_a*cos_psi_a;
	R_a[1][1] = cos_phi_a*cos_psi_a + sin_phi_a*sin_teta_a*sin_psi_a;
	R_a[2][0] = sin_phi_a*sin_psi_a + cos_phi_a*sin_teta_a*cos_psi_a;
	R_a[2][1] = -sin_phi_a*cos_psi_a + cos_phi_a*sin_teta_a*sin_psi_a;
	/*double det = 0;
	det += R_a[0][0] * (R_a[1][1] * R_a[2][2] - R_a[1][2] * R_a[2][1]);
	det -= R_a[0][1] * (R_a[1][0] * R_a[2][2] - R_a[1][2] * R_a[2][0]);
	det += R_a[0][2] * (R_a[1][0] * R_a[2][1] - R_a[1][1] * R_a[2][0]);
	printf("Matrice. Det=%f\n ", det);
	printf("%f %f %f\n", R_a[0][0], R_a[0][1], R_a[0][2]);
	printf("%f %f %f\n", R_a[1][0], R_a[1][1], R_a[1][2]);
	printf("%f %f %f\n", R_a[2][0], R_a[2][1], R_a[2][2]);*/
}

// Calculates quaternion from a rotation matrix
void IMU_class::calculate_quaternion_elements_a(){
	q_a[0] = 0.5f * sqrt(1.0f + R_a[0][0] + R_a[1][1] + R_a[2][2]);
	q_a[1] = (R_a[2][1] - R_a[1][2]) / (4.0f * q_a[0]);
	q_a[2] = (R_a[0][2] - R_a[2][0]) / (4.0f * q_a[0]);
	q_a[3] = (R_a[1][0] - R_a[0][1]) / (4.0f * q_a[0]);
	normalize_quaternion(q_a); // modulus becomes 1
	//printf("%f %f %f %f\n\n", q_a[0], q_a[1], q_a[2], q_a[3]);
}

// Calculates Yaw Pitch Roll angles from quaternion
void IMU_class::calculate_yawpitchroll_from_quaternions(double* q_in, double* yaw_out, double* pitch_out, double* roll_out){
	*yaw_out = atan2f((float)(2.0f * q_in[1] * q_in[2] - 2.0f * q_in[0] * q_in[3]), (float)(2.0f * q_in[0] * q_in[0] + 2.0f * q_in[1] * q_in[1] - 1.0f));
	*pitch_out = (-1.0f) * asinf((float)(2.0f * q_in[1] * q_in[3] + 2.0f * q_in[0] * q_in[2]));
	*roll_out = atan2f((float)(2.0f * q_in[2] * q_in[3] - 2.0f * q_in[0] * q_in[1]), (float)(2.0f * q_in[0] * q_in[0] + 2.0f * q_in[3] * q_in[3] - 1.0f));
	printf("Yawt=%f Pitcht= %f Roll=%f\n", RAD_TO_DEG * (*yaw_out), RAD_TO_DEG * (*pitch_out), RAD_TO_DEG * (*roll_out));
}

// Retreives sensors raw data from the packet received
void IMU_class::parse_incoming_packet(){
	ax = *((short*)&(packet_data[0]));
	ay = *((short*)&(packet_data[2]));
	az = *((short*)&(packet_data[4]));
	gx = *((short*)&(packet_data[6]));
	gy = *((short*)&(packet_data[8]));
	gz = *((short*)&(packet_data[10]));
	packet_counter = *((unsigned short*)&(packet_data[12]));
}

// Correct signs, scales inputs, and transforms data into floating point format
void IMU_class::correct_raw_data(){

	// Correct signs (Arduino 101 sensors signal has some axis with negative signs)
	ay = -ay;
	gy = -gy;
	gz = gz;

	// Correct offset (based on estimated offset values), if flag is activated
	if (G_OFFSET_CORR_ACT_FLAG){
		gx -= gx_offset;
		gy -= gy_offset;
		gz -= gz_offset;
	}

	// Calculates modulus of acceleration vector
	ax_f = (double)ax;
	ay_f = (double)ay;
	az_f = (double)az;
	double acc_mod_inv = (double)invSqrt((float)(ax_f*ax_f + ay_f*ay_f + az_f*az_f));
	a_modulus = (short)(1 / acc_mod_inv); // invert the number to obtain the modulo

	// Normalizes acceleration data inside [-1, +1] range
	ax_f *= acc_mod_inv;
	ay_f *= acc_mod_inv;
	az_f *= acc_mod_inv;
	/*// Checks that numbers are into [-1, +1] range (maybe this check is not necessary)
	if (ax_f < -1.0) ax_f = -1.0;
	if (ax_f > -1.0) ax_f = 1.0;
	if (ay_f < -1.0) ay_f = -1.0;
	if (ay_f > -1.0) ay_f = 1.0;
	if (az_f < -1.0) az_f = -1.0;
	if (az_f > -1.0) az_f = 1.0;*/

	// Transforms gyroscope data from raw data into rad/s
	gx_f = GYRO_TO_RAD*(double)gx;
	gy_f = GYRO_TO_RAD*(double)gy;
	gz_f = GYRO_TO_RAD*(double)gz;
}

/*
void IMU_class::calculation_task(){

	correct_raw_data(); // corrects sign and scale of raw data, and transforms into floating point format
	integrate_quaternion_g(q_fuse, q_g); // calculates "gyroscope" quaternion by integrating the gyroscope data, based on input quaternion
	calculate_yawpitchroll_from_quaternions(q_g, &yaw_fuse, &pitch_fuse, &roll_fuse);
	calculate_rotation_matrix_elements_a(yaw_fuse); // calculates rotation matrix elements from acceleration data
	//calculate_rotation_matrix_elements_a(0.0); // calculates rotation matrix elements from acceleration data
	calculate_quaternion_elements_a(); // calculates "accelerometer" quaternion starting from rotation matrix
	fuse_quaternions(q_a, q_g, q_fuse, (double)filter_requested); // fuses "accelerometer" quaternion and "gyroscope" quaternion

	calculate_yawpitchroll_from_quaternions(q_fuse, &yaw_fuse, &pitch_fuse, &roll_fuse);
	//calculate_yawpitchroll_from_quaternions(q_a, &yaw_a, &pitch_a, &roll_a);
	yaw_a = 0.0;
	pitch_a = asin(sin_teta_a);
	roll_a = asin(sin_phi_a);
}*/

// Calculation task assumes that raw data (ax, ay, az, gx, gy, gz) has already been acquired
// This function performs all calculations, starting from data correction to yaw, pitch, roll calculation
void IMU_class::calculation_task(){

	correct_raw_data(); // corrects sign and scale of raw data, and transforms into floating point format
	update_filter_constant_using_acc_history(); // updates filter and offsets values
	if (yaw_bypass_request) { // Bypass yaw to constant value
		calculate_rotation_matrix_elements_a(0.0); // calculates rotation matrix elements from acceleration data
	}else{
		calculate_rotation_matrix_elements_a(yaw_fuse); // calculates rotation matrix elements from acceleration data
	}
	calculate_quaternion_elements_a(); // calculates "accelerometer" quaternion (q_a) starting from rotation matrix
	fuse_quaternions(q_a, q_fuse, q_g, (double)filter_requested); // fuses "accelerometer" quaternion and previous quaternion (to have a faster response, using latest accelerometer data)
	integrate_quaternion_g(q_g, q_fuse); // calculates "gyroscope" quaternion by integrating the gyroscope data, based on input quaternion
	calculate_yawpitchroll_from_quaternions(q_fuse, &yaw_fuse, &pitch_fuse, &roll_fuse);
	yaw_a = 0.0;
	pitch_a = asin(sin_teta_a);
	roll_a = asin(sin_phi_a);
}

IMU_class::IMU_class(){
	packet_data = NULL;
	ax = 0;
	ay = 0;
	az = 0;
	a_modulus = 0;
	gx = 0;
	gy = 0;
	gz = 0;
	ax_f = 0;
	ay_f = 0;
	az_f = 0;
	gx_f = 0;
	gy_f = 0;
	gz_f = 0;
	packet_counter = 0;

	q_g[0] = 1; // quaternion (gyroscope)
	q_g[1] = 0; // quaternion (gyroscope)
	q_g[2] = 0; // quaternion (gyroscope)
	q_g[3] = 0; // quaternion (gyroscope)

	q_fuse[0] = 1; // quaternion (fusion)
	q_fuse[1] = 0; // quaternion (fusion)
	q_fuse[2] = 0; // quaternion (fusion)
	q_fuse[3] = 0; // quaternion (fusion)

	q_diff[0] = 0; // quaternion difference (n-th step minus previous)
	q_diff[1] = 0; // quaternion difference (n-th step minus previous)
	q_diff[2] = 0; // quaternion difference (n-th step minus previous)
	q_diff[3] = 0; // quaternion difference (n-th step minus previous)

	// resets acceleration sensors history
	unsigned int i = 0;
	a_samples_index=0;
	for (i = 0; i < A_HIST_NUM; i++){
		a_samples_hist[i] = 0;
	}

	// resets gyroscope sensors history
	g_samples_index = 0;
	for (i = 0; i < G_HIST_NUM; i++){
		gx_samples_hist[i] = 0;
		gy_samples_hist[i] = 0;
		gz_samples_hist[i] = 0;
		q_diff_hist[i][0] = 0;
		q_diff_hist[i][1] = 0;
		q_diff_hist[i][2] = 0;
		q_diff_hist[i][3] = 0;
	}

	gx_offset = 0;
	gy_offset = 0;
	gz_offset = 0;

	q_diff_offset[0] = 0;
	q_diff_offset[1] = 0;
	q_diff_offset[2] = 0;
	q_diff_offset[3] = 0;

	filter_requested = 0.5;

	yaw_bypass_request = 0;
}
#include <tchar.h>
#include "SerialClass.h"
#include <string>
#include <conio.h>
#include <time.h>
#include <math.h>
#include "IMU.h"

#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>

// constants needed for the software running
#define DEAD_TIME_SERIAL_RECEIVE 10 // dead before checking packet contents
#define POLLING_PERIOD_MS 50 // polling period in ms

// Parameters for input output files and verbose
#define ACTIVATE_LOGGING_RAW 1 // logging function is activated
#define ACTIVATE_EXPORT_CALC 1 // activate export of calculated data
#define SIMULATION_FROM_FILE 1 // in this case the data is received from file instead of receiving it from sensor
#define VERBOSE_MODE 0 // shows the data calculated on the display
#define REAL_TIME_SHOW 1 // waits in order to show at real time
#define K_FILTER_SHOW (float)0.5 // FIR to show actual data

static void error_callback(int error, const char* description)
{
	fputs(description, stderr);
}

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
	if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
		glfwSetWindowShouldClose(window, GL_TRUE);
}

int send_command_req(char* comandi, int lunghezza, Serial* SP){
	if (SP->WriteData(comandi, lunghezza) == true) {
		return 0;
	}
	else{
		return 1;
	}
}

void calculate_GPS_checksum(unsigned char* data_array, unsigned int start, unsigned int length, unsigned char* CK_A, unsigned char* CK_B){
	*CK_A = 0;
	*CK_B = 0;
	unsigned int i = 0; // counter
	for (i = 0; i<length; i++){
		*CK_A = *CK_A + data_array[start + i];
		*CK_B = *CK_B + *CK_A;
	}
}

void draw_box(float x0, float y0, float z0, float dx, float dy, float dz){
	
	//Multi-colored side - FRONT
	glBegin(GL_POLYGON);
	glColor3f(1.0, 0.0, 0.0);     
	glVertex3f(x0 + dx, y0, z0); 
	glVertex3f(x0 + dx, y0 + dy, z0);
	glVertex3f(x0, y0 + dy, z0);
	glVertex3f(x0, y0, z0);
	glEnd();

	// White side - BACK
	glBegin(GL_POLYGON);
	glColor3f(1.0, 0.0, 0.0);
	glVertex3f(x0 + dx, y0, z0 + dz);
	glVertex3f(x0 + dx, y0 + dy, z0 + dz);
	glVertex3f(x0, y0 + dy, z0 + dz);
	glVertex3f(x0, y0, z0 + dz);
	glEnd();

	// Purple side - RIGHT
	glBegin(GL_POLYGON);
	glColor3f(0.0, 1.0, 0.0);
	glVertex3f(x0 + dx, y0, z0);
	glVertex3f(x0 + dx, y0 + dy, z0);
	glVertex3f(x0 + dx, y0 + dy, z0 + dz);
	glVertex3f(x0 + dx, y0, z0 + dz);
	glEnd();

	// Green side - LEFT
	glBegin(GL_POLYGON);
	glColor3f(0.0, 1.0, 0.0);
	glVertex3f(x0, y0, z0 + dz);
	glVertex3f(x0, y0 + dy, z0 + dz);
	glVertex3f(x0, y0 + dy, z0);
	glVertex3f(x0, y0, z0);
	glEnd();

	// Blue side - TOP
	glBegin(GL_POLYGON);
	glColor3f(0.0, 0.0, 1.0);
	glVertex3f(x0 + dx, y0 + dy, z0 + dz);
	glVertex3f(x0 + dx, y0 + dy, z0);
	glVertex3f(x0, y0 + dy, z0);
	glVertex3f(x0, y0 + dy, z0 + dz);
	glEnd();

	// Red side - BOTTOM
	glBegin(GL_POLYGON);
	glColor3f(0.0, 0.0, 1.0);
	glVertex3f(x0 + dx, y0, z0);
	glVertex3f(x0 + dx, y0, z0 + dz);
	glVertex3f(x0, y0, z0 + dz);
	glVertex3f(x0, y0, z0);

	glEnd();
}


int _tmain(int argc, _TCHAR* argv[])
{

	// GLEW INIT
	GLFWwindow* window;
	glfwSetErrorCallback(error_callback);
	if (!glfwInit())
		exit(EXIT_FAILURE);
	window = glfwCreateWindow(640, 480, "IMU Example - GLFW", NULL, NULL);
	if (!window)
	{
		glfwTerminate();
		exit(EXIT_FAILURE);
	}
	glfwMakeContextCurrent(window);
	glfwSetKeyCallback(window, key_callback);
	glEnable(GL_DEPTH_TEST);
	float ratio;
	int width, height;
	glfwGetFramebufferSize(window, &width, &height);
	ratio = width / (float)height;
	glViewport(0, 0, width, height);

	float yaw_show_now = 0;
	float pitch_show_now = 0;
	float roll_show_now = 0;
	float yaw_show_old = 0;
	float pitch_show_old = 0;
	float roll_show_old = 0;

	bool quit_request = false;
	bool in_file_open_ok = false; // file opened correctly
	bool out_file_open_ok = false; // file opened correctly
	bool serial_open_ok = false; // serial port opened correctly
	unsigned int error_counter = 0;
	int command_mode = 0;
	char incomingData[256];	// sent data buffer
	int dataLength = 256; // size of receiving buffer
	int readResult = 0; // characters read
	char tasto; // pressed key
	char comandi[256]; // command sent by serial
	comandi[0] = 's';
	unsigned long file_size = 0;
	unsigned long char_read_file = 0;
	unsigned char CK_A, CK_B;
	
	unsigned int ack_delay = DEAD_TIME_SERIAL_RECEIVE;
	unsigned int correct_receival_flags_index = 0;
	bool correct_receival_flags_max_reached = false; // not yet crossed 100

	IMU_class* IMU;
	IMU = new IMU_class;
	IMU->packet_data = incomingData;

	// FILES (I/O) and SERIAL (Input)
	FILE *fp_write_raw = NULL;
	FILE *fp_write_calc = NULL;
	FILE *fp_read = NULL;
	errno_t err;
	Serial* SP = NULL;
	// LOGGING (RAW)
	if (ACTIVATE_LOGGING_RAW){ // Open file for logging raw data
		err = fopen_s(&fp_write_raw, "output_raw.log", "wb");
		if (err == 0)
		{
			printf("The file 'output_raw.log' was opened\n");
		}
		else
		{
			printf("The file 'output_raw.log' was not opened\n");
		}
	}
	// LOGGING (CALC)
	if (ACTIVATE_EXPORT_CALC){ // Open file for logging raw data
		err = fopen_s(&fp_write_calc, "output_cal.csv", "wb");
		if (err == 0)
		{
			printf("The file 'output_cal.csv' was opened\n");
			fprintf(fp_write_calc, "PacketCnt,");
			fprintf(fp_write_calc, "ax,ay,az,");
			fprintf(fp_write_calc, "gx,gy,gz,");
			fprintf(fp_write_calc, "yaw_a[deg],pitch_a[deg],roll_a[deg],");
			fprintf(fp_write_calc, "yaw_fuse[deg],pitch_fuse[deg],roll_fuse[deg],");
			fprintf(fp_write_calc, "\n");
		}
		else
		{
			printf("The file 'output_cal.csv' was not opened\n");
		}
	}
	// INPUT DATA
	if (SIMULATION_FROM_FILE){ // use file as input
		err = fopen_s(&fp_read, "input.log", "rb");
		if (err == 0)
		{
			printf("The file 'input.log' was opened\n");
			in_file_open_ok = true;
		}
		else
		{
			printf("The file 'input.log' was not opened\n");
			in_file_open_ok = false;
		}
	}
	else{ // use serial as input
		printf("Serial Communication Test\n");
		SP = new Serial("\\\\.\\COM8"); // Open Serial Port
		if (SP->IsConnected()){
			printf("Serial initialized successfully\n");
			serial_open_ok = true;
		}
		else{
			printf("Could not initialize serial. Press any key to exit\n");
			serial_open_ok = false;
		}
	}

	// Starting time
	clock_t t1, t2;
	t1 = clock(); // read present time in ms
	while (quit_request == false){

		// GET DATA FROM FILE OR SERIAL
		if (SIMULATION_FROM_FILE && (fp_read != NULL)){ // Case in which data is read from file, and there is a file pointer open
			readResult = 0;
			while ((readResult < 16)){ // read 16 chars unless end of file
				if (feof(fp_read) == 0){ // not arrived to the end of file
					incomingData[readResult] = fgetc(fp_read); // read data from file
					readResult++;
				}
				else{
					quit_request = true; // arrived at the end of the file
					break; // Exit while cycle
				}
			}
		}
		else if (!SIMULATION_FROM_FILE){ // Case in which data is read from Serial
			send_command_req(comandi, 1, SP);
			Sleep(DEAD_TIME_SERIAL_RECEIVE);
			readResult = SP->ReadData(incomingData, dataLength);
		}
		else{ // not valid mode
			quit_request = true;
		}
		// ANALYZE DATA (in case data has correct size and checksum)
		if (readResult == PACKET_SIZE){
			calculate_GPS_checksum((unsigned char*)incomingData, 0, PACKET_SIZE-2, &CK_A, &CK_B);
			if ((CK_A == (unsigned char)incomingData[PACKET_SIZE - 2]) && (CK_B == (unsigned char)incomingData[PACKET_SIZE-1])){ // Checksum check
				
				IMU->parse_incoming_packet();
				IMU->calculation_task();

				// VERBOSE and DATA LOGGING
				if (VERBOSE_MODE){ // Shows the data on the display
					t2 = clock();
					printf("%f %d ", (float)(t2 - t1) / ((float)CLOCKS_PER_SEC), IMU->packet_counter);
					//printf("%f %d %f %f %f %d %d %d ", (double)(t2 - t1) / ((double)CLOCKS_PER_SEC), packet_counter, IMU->ax_f, IMU->ay_f, IMU->az_f, IMU->gx, IMU->gy, IMU->gz);
					printf("%d %d %d ", IMU->gx, IMU->gy, IMU->gz);
					printf("%f ", (IMU->yaw_a) * RAD_TO_DEG);
					printf("%f ", (IMU->pitch_a) * RAD_TO_DEG);
					printf("%f ", (IMU->roll_a) * RAD_TO_DEG);
					printf("\n");
				}
				if (ACTIVATE_LOGGING_RAW && (fp_write_raw != NULL)) fwrite(&(incomingData[0]), sizeof(char), 16, fp_write_raw); // writes raw data to the file
				if (ACTIVATE_EXPORT_CALC && (fp_write_calc != NULL)) {
					fprintf(fp_write_calc, "%d,", IMU->packet_counter);
					fprintf(fp_write_calc, "%d,%d,%d,", IMU->ax, IMU->ay, IMU->az);
					fprintf(fp_write_calc, "%d,%d,%d,", IMU->gx, IMU->gy, IMU->gz);
					fprintf(fp_write_calc, "%f,%f,%f,", (IMU->yaw_a) * RAD_TO_DEG, (IMU->pitch_a) * RAD_TO_DEG, (IMU->roll_a) * RAD_TO_DEG);
					fprintf(fp_write_calc, "%f,%f,%f,", (IMU->yaw_fuse) * RAD_TO_DEG, (IMU->pitch_fuse) * RAD_TO_DEG, (IMU->roll_fuse) * RAD_TO_DEG);
					fprintf(fp_write_calc, "%f,%f,%f,%f,", IMU->q_fuse[0], IMU->q_fuse[1], IMU->q_fuse[2], IMU->q_fuse[3]);
					fprintf(fp_write_calc, "%f,", IMU->filter_requested);
					fprintf(fp_write_calc, "\n");
				}
			}
			else{
				printf("Checksum error: %d %d %d %d\n", CK_A, CK_B, (unsigned char)incomingData[14], (unsigned char)incomingData[15]);
			}
		}
		else{
			printf("Wrong size: %d\n", readResult);
		}

		// OpenGL UPDATE
		if (!glfwWindowShouldClose(window))
		{
			glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
			glMatrixMode(GL_PROJECTION);
			glLoadIdentity();
			glOrtho(-ratio, ratio, -1.f, 1.f, 1.f, -1.f);
			glMatrixMode(GL_MODELVIEW);
			glLoadIdentity();

			// Rotate the object using quaternion, and draw it
			double quat_angle = acos(IMU->q_fuse[0]);
			double quat_x = IMU->q_fuse[1] / sin(quat_angle);
			double quat_y = IMU->q_fuse[2] / sin(quat_angle);
			double quat_z = IMU->q_fuse[3] / sin(quat_angle);
			glRotatef(2*(180.0/3.14)*quat_angle, quat_y, -quat_z, quat_x);
			draw_box(-0.4, -0.05, -0.2, 0.8, 0.1, 1.0);

			glfwSwapBuffers(window);
			glfwPollEvents();
		}

		// KEYBOARD KEY CHECK
		if (_kbhit() != 0){
			tasto = _getch();
			if (tasto == 'q') quit_request = true;
			if (tasto == 'b'){ // Toggle yaw bypass request flag
				if (IMU->yaw_bypass_request == 0){
					IMU->yaw_bypass_request = 1;
				}
				else{
					IMU->yaw_bypass_request = 0;
				}
			}
		}

		// WAITING TIME (to have always the same execution time)
		if (REAL_TIME_SHOW){ // only in case of data coming from Serial, no need for simulation
			do{
				t2 = clock();
				Sleep(1); // sleep 1ms
			} while (((double)(t2 - t1) / ((double)CLOCKS_PER_SEC)) < 1);
			t1 += POLLING_PERIOD_MS*CLOCKS_PER_SEC / 1000; // update old
		}
	}

	// Closes Serial and Files
	if (SP) SP->~Serial(); // close serial
	if (fp_write_raw) fclose(fp_write_raw);
	if (fp_write_calc) fclose(fp_write_calc);
	if (fp_read) fclose(fp_read);
	
	// OpenGL
	glfwDestroyWindow(window);
	glfwTerminate();
	exit(EXIT_SUCCESS);

	getchar(); // wait to exit

	return 0;
}

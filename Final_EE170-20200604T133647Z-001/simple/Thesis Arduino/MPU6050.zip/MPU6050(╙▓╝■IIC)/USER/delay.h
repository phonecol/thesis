#ifndef _DELAY__H_
#define _DELAY__H_

void delay_us(u32 n);
void delay_ms(u32 n);

#endif

# Attitude and Position reference system using IMU + GPS data.

Extract #4 from the Málaga Stereo and Laser Urban Data Set (http://www.mrpt.org/MalagaUrbanDataset#33_Binary_files) has been used.

Run main_INS.m to obtain the results.

References:

J. A. Farrel, Aided navigation GPS with high rate sensors. New York: The McGRaw-Hill Companies, 2008.

P. Kim, Kalman Filter for Beginners: with MATLAB Examples. CreateSpace Independent Publishing Platform, 2011.

# Eigen
A port of the Eigen linear algebra library for Arduino

This is a port of Eigen 3.3.5. This library is known to work with Teensy 3.x, Teensy LC, and STM32L4 Ladybug devices.

To install, simply clone or download this library into your Arduino/libraries folder. Please see [Eigen's website](https://eigen.tuxfamily.org/dox/index.html) for documentation.

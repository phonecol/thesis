function varargout = Fin170(varargin)
% FIN170 MATLAB code for Fin170.fig
%      FIN170, by itself, creates a new FIN170 or raises the existing
%      singleton*.
%
%      H = FIN170 returns the handle to a new FIN170 or the handle to
%      the existing singleton*.
%
%      FIN170('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in FIN170.M with the given input arguments.
%
%      FIN170('Property','Value',...) creates a new FIN170 or raises the
%      existing singleton*.  Starting from the camleft, property value pairs are
%      applied to the GUI before Fin170_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      thruster.  All inputs are passed to Fin170_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Fin170

% Last Modified by GUIDE v2.5 20-May-2020 13:02:30

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Fin170_OpeningFcn, ...
                   'gui_OutputFcn',  @Fin170_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Fin170 is made visible.
function Fin170_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Fin170 (see VARARGIN)

axes(handles.Camera);
vid=videoinput('winvideo', 1);
hImage=image(zeros(720, 1280, 3), 'Parent', handles.Camera);
preview(vid,hImage);
camorbit(180,180);
axis off;

axes(handles.capturedpic);
axis off;
axes(handles.boatpic);
image(imread('boat.png'));
axis off;
axes(handles.IMU1axes);
axis off;
axes(handles.IMU2axes);
image(imread('rpw.png'));
axis off;
axes(handles.gpsmap);
image(imread('gpss.png'));
axis off;
axes(handles.batpercent);
image(imread('0.png'));
axis off;

datern = datestr(now, 'mm-dd-yyyy');
myString = sprintf('%s', datern);
handles.date.String = myString;
        
% 
% s = sprintf('RIGHT');
% set(handles.camright, 'TooltipString', s)
% s = sprintf('LEFT');
% set(handles.camleft, 'TooltipString', s)
% s = sprintf('CENTER');
% set(handles.center, 'TooltipString', s)
% s = sprintf('FORWARD/STOP');
% set(handles.thruster, 'TooltipString', s)


% Choose default command line output for Fin170
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Fin170 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Fin170_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

% --- Executes on button press in arduino.
function arduino_Callback(hObject, eventdata, handles)
% hObject    handle to arduino (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of arduino
ispushed= get(hObject, 'Value');
if ispushed 
    
      set(hObject, 'String', 'STOP');
      set(handles.sysstatus, 'String', 'ON');
      set(handles.arduino,'BackgroundColor',[1 0 0]);
      %set(handles.sysstatus, 'backgroundcolor', 'g');
         if ~isempty(instrfind)
             fclose(instrfind);
             delete(instrfind);
         end
        global xx;
        g = instrhwinfo('serial');
        gg = g.AvailableSerialPorts;
        ggg = char(gg);
        xx = serial(ggg,'BAUD', 9600);
   
        hold on
        A = [0 0 0];
        B = [1 0 0];
        C = [0 1 0];
        D = [0 0 1];
        E = [0 1 1];
        F = [1 0 1];
        G = [1 1 0];
        H = [1 1 1];
        D(3)=D(3)*0.3;
        F(3)=F(3)*0.3;
        E(3)=E(3)*0.3;
        H(3)=H(3)*0.3;
        A(1)=A(1)+0.2;
        D(1)=D(1)+0.2;
        F(1)=F(1)-0.2;
        B(1)=B(1)-0.2;
        Center=H/2;
        axes_plot_sample = 0;
        axes_plot_sample_interval = 4;
        has_drawn = 0;
        fopen(xx);
        cnt = 1;

    while 1
    %tic
    d = fscanf(xx);
    
    %Multiple read
    [t1,remain] = strtok(d, ','); %voltage
    r1 = remain;
    [t2,remain] = strtok(r1, ',');%current
    r2 = remain;
    [t3,remain] = strtok(r2, ',');%pitch 
    r3 = remain;
    [t4,remain] = strtok(r3, ',');%roll
     r4 = remain;
    [t5,remain] = strtok(r4, ',');%yaw

    data(1,cnt) = cnt;
    data(2,cnt) = str2double(t1);
    data(3,cnt) = str2double(t2);
    data(4,cnt) = str2double(t3);
    data(5,cnt) = str2double(t4);
    data(6,cnt) = str2double(t5);
    
    set(handles.longitude,'string',t1);
    set(handles.latitude,'string',t2);
    set(handles.pitch,'string',t3);
    set(handles.roll,'string',t4);
    set(handles.yaw,'string',t5);
    
    if axes_plot_sample == axes_plot_sample_interval
    %% Battery Calculation
    vl = data(2,cnt);
    cu = data(3,cnt);
    vi = 0.50*cu + vl;
    vr = (13.68-vi)/(vi-9);
    cp = 100/(vr+1);
    if cu <= 0 && vl <= 0
        cp = 0;
    end
    
    aa = cp;
    val = round(aa);
    set(handles.batper,'String',num2str(val));
    if val >= 75
    batper = imread('100.png');
    axes(handles.batpercent);
    imshow(batper);
    elseif val < 75 && val >= 50
    batper = imread('75.png');
    axes(handles.batpercent);
    imshow(batper);
    elseif val < 50 && val >= 20
    batper = imread('50.png');
    axes(handles.batpercent);
    imshow(batper);
    elseif val < 20 && val >= 1
    batper = imread('25.png');
    axes(handles.batpercent);
    imshow(batper);
    else
    batper = imread('0.png');
    axes(handles.batpercent);
    imshow(batper);
    end
    
       %% IMU 2D and 3D representation
   dcm = angle2dcm(data(6,cnt),data(4,cnt),data(5,cnt));
   P = [A;B;F;H;G;C;A;D;E;H;F;D;E;C;G;B];
   for i=1:length(P)
       P(i,:)=P(i,:)-Center;
   end
   P = P*dcm;
   for i=1:length(P)
       P(i,:)=P(i,:)+Center;
   end
   axes(handles.IMU1axes); %2D representation
   plot(data(1,:),data(5,:),'g',data(1,:),data(4,:),'b',data(1,:),data(6,:),'r');
   ylim([-2 2])
   axes(handles.IMU2axes); %3D representaion
   plot3(P(:,1),P(:,2),P(:,3),'Color','r');
   hold on;
   %%
   hold off;
   axis([-2 2 -2 2 -2 2]);
   
   view([1,1,1]) ;
   xlabel('X');
   ylabel('Y');
   zlabel('Z');
   axes_plot_sample = 0;
    end 
   if ~has_drawn && (axes_plot_sample == axes_plot_sample_interval)
       drawnow;
       has_drawn = 1;
   else
       drawnow;
   end
 
   %% Limit the size of data
   [f,ff] = size(data);
    if ff > 100
          data(:,:) = [];
          data =zeros(5,100);
          cnt = 0;
    end
    cnt = cnt + 1;
 
    %%
    axes_plot_sample = axes_plot_sample + 1;
    %toc
    end

 
else
    set(hObject, 'String', 'START');
    set(handles.sysstatus, 'String', 'OFF');
    set(handles.arduino,'BackgroundColor',[0 1 0]);
   % set(handles.sysstatus, 'backgroundcolor', 'r');
     if ~isempty(instrfind)
             fclose(instrfind);
             delete(instrfind);
     end
         
    nodata1 = imread('nodata.png');
        axes(handles.IMU1axes);
        imshow(nodata1);
    nodata2 = imread('nodata.png');
        axes(handles.IMU2axes);
        imshow(nodata2);
         f= errordlg('Click START button to operate again.', 'System off!'); 
end


% --- Executes on button press in Capture.
function Capture_Callback(hObject, eventdata, handles)
% hObject    handle to Capture (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
fulldate = datestr(now, 'yyyy-mm-ddTHHMMSSZ');
F = getframe(handles.Camera);
Image = frame2im(F);
savename= strcat ('C:\Users\Kate Augusto\Documents\EE\5th Year 1\EE 170\Final_EE170\Pictures\', num2str(fulldate), '.jpg');
imwrite(Image, savename);
imshow(Image, 'Parent', handles.capturedpic);


% --- Executes on button press in IMU1push.
function IMU1push_Callback(hObject, eventdata, handles)
% hObject    handle to IMU1push (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
uistack(handles.IMU1,'top')
set(handles.IMU1, 'Visible', 'on');
set(handles.IMU2, 'Visible', 'off');

% --- Executes on button press in IMU2push.
function IMU2push_Callback(hObject, eventdata, handles)
% hObject    handle to IMU2push (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
uistack(handles.IMU2,'top')
set(handles.IMU2, 'Visible', 'on');
set(handles.IMU1, 'Visible', 'off');


% --- Executes on slider movement.
function speed_Callback(hObject, eventdata, handles)
% hObject    handle to speed (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global xx;
val = get(hObject,'Value');
nval = val*(100/4);
dval= num2str(round(nval));
set(handles.speedstat,'String',num2str(dval));

switch val 
    case 0
        send = '0';
    case 1
        send = '1';
    case 2
        send = '2';
    case 3
        send = '3';
    case 4 
        send = '4';
end

fprintf(xx, send);





% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function speed_CreateFcn(hObject, eventdata, handles)
% hObject    handle to speed (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



% --- Executes on button press in camright.
function right_Callback(hObject, eventdata, handles)
% hObject    handle to camright (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global xx;
send ='D';
fprintf(xx, send);

% --- Executes on button press in camleft.
function left_Callback(hObject, eventdata, handles)
% hObject    handle to camleft (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global xx;
send ='A';
fprintf(xx, send);

% --- Executes on button press in center.
function center_Callback(hObject, eventdata, handles)
% hObject    handle to center (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global xx;
send ='Q';
fprintf(xx, send);


% --- Executes on button press in thruster.
function thruster_Callback(hObject, eventdata, handles)
% hObject    handle to thruster (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global xx;
ispushed= get(hObject, 'Value');

if ispushed
    set(hObject, 'String', 'STOP');
%     x = 444;
%     y = 255;
%     set(handles.speed,'Value',255/2);
%     set(handles.speedstat,'String',50);
%     x = num2str(x);
%     y = num2str(y);
%     send =[ x,',',y];
    send = 'W';
    fprintf(xx, send);

else
    set(hObject, 'String', 'MOVE');
%     x = 444;
%     y = 0;
%     set(handles.speed,'Value',0);
%     set(handles.speedstat,'String',0);
%     x = num2str(x);
%     y = num2str(y);
%     send =[ x,',',y];
    send = 'S';
    fprintf(xx, send);   
end


% --- Executes on button press in conveyor.
function conveyor_Callback(hObject, eventdata, handles)
% hObject    handle to conveyor (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global xx;
ispushed= get(hObject, 'Value');

if ispushed
   set(hObject, 'String', 'ON');
    send = 'C' ;
    fprintf(xx, send);
else
   set(hObject, 'String', 'OFF');
    send = 'V' ;
    fprintf(xx, send);
 
end
% Hint: get(hObject,'Value') returns toggle state of conveyor





% --- Executes on button press in pushbutton23.
function pushbutton23_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton23 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
f= msgbox({'For keyboard shortcuts:' ; '' ; 'Rudder Left = leftarrow'; 
  'Rudder Right = rightarrow' ; 'Rudder Center = uparrow' ; 'Move/Stop = downarrow'
  ; 'Camera Left = a'  ; 'Camera Center = s'  ; 'Camera Right = d'});



function keyshort_Callback(hObject, eventdata, handles)
% hObject    handle to keyshort (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of keyshort as text
%        str2double(get(hObject,'String')) returns contents of keyshort as a double


% --- Executes during object creation, after setting all properties.
function keyshort_CreateFcn(hObject, eventdata, handles)
% hObject    handle to keyshort (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on key press with focus on keyshort and none of its controls.
function keyshort_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to keyshort (see GCBO)
% eventdata  structure with the following fields (see MATLAB.UI.CONTROL.UICONTROL)
%	Key: name of the key that was pressed, in lower case
%	Character: character interpretation of the key(s) that was pressed
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) pressed
% handles    structure with handles and user data (see GUIDATA)

keyPressed = eventdata.Key;

switch keyPressed
    case 'uparrow'
        pushbutton1_Callback(handles.center,[],handles);
    case 'leftarrow'
        left_Callback(handles.left,[],handles); 
    case 'rightarrow'
        pushbutton1_Callback(handles.right,[],handles); 
    case 'downarrow'
        thruster_Callback(handles.thruster,[],handles);
    case 'a'
        pushbutton1_Callback(handles.camleft,[],handles); 
    case 's'
        pushbutton1_Callback(handles.camcenter,[],handles); 
    case 'd'
         pushbutton1_Callback(handles.camright,[],handles);
         
end       
 


% --- Executes on button press in pushbutton26.
function pushbutton26_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton26 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton27.
function pushbutton27_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton27 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
